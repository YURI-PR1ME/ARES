/************************************************************************************************** 
24c02.c:�洢����ʼ����д����
***************************************************************************************************/

#include "config.h"



void delay_2()
{ ; ; }

void start()//iic��ʼ�ź�
{
	sda=1;	
	delay_2();
	scl=1;
	delay_2();
	sda=0;
	delay_2();
}
void stop()//IIcֹͣ�ź�
{
	sda=0;
	delay_2();
	scl=1;
	delay_2();
	sda=1;
	delay_2();
}
void respons()  //iicӦ���ź�
{
	uch8 i;
	scl=1;
	delay_2();
	while((sda==1)&&(i<250))i++;
	scl=0;
	delay_2();
}
void  ic_init()//iic��ʼ��
{
 	scl=1;
 	delay_2();
	sda=1;
	delay_2();
}
void write_byte(uch8 date)//��iicд��������
{
	uch8 i,temp;
	temp=date;


	for(i=0;i<8;i++)
	{
		temp=temp<<1;
		scl=0;
	    delay_2();
		sda=CY;
		delay_2();
		scl=1;
		delay_2();
	//	scl=0;
     //   delay();
	}
	scl=0;
	delay_2();
	sda=1;
	delay_2();
}
uch8 read_byte()//��iic����������
{
	uch8 i,k;
	scl=0;
	delay_2();
	sda=1;
	delay_2();
	for(i=0;i<8;i++)
	{
		scl=1;
		delay_2();	
		k=(k<<1)|sda;
		scl=0;
		delay_2();	
	}
	return k;
}
void write_add(uch8 address,uch8 date)//��iic�̶���ַд����
{
	start();
	write_byte(0xa0);
	respons();
	write_byte(address);
	respons();
	write_byte(date);
	respons();
	stop();
}
uch8 read_add(uch8 addr)//��iic�̶���ַ������
{
	uch8 date;
	start();
	write_byte(0xa0);
	respons();
	write_byte(addr);
	respons();
	start();
	write_byte(0xa1);
	respons();
	date=read_byte();
	stop();
	return date;
}
